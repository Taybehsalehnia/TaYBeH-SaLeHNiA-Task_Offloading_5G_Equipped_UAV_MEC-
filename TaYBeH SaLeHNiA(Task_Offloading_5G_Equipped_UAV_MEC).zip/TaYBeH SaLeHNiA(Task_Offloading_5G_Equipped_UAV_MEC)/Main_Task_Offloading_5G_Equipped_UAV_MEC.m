%===========================================================
% Programer: Taybeh Salehnia
% Email: salehnia.taybeh@gmail.com
%===========================================================
clc; clear; close all; rng(1);

%% ==========================================================
%                  SYSTEM PARAMETERS
% ==========================================================
params.N_UAV   = 6;
params.N_TASK  = 1000;
params.Area    = 1000;
params.H       = 20;

params.fc      = 5e6;
params.B       = 20e6;
params.c       = 3e8;
params.sigma2  = 10^(-104/10);

params.P_UAV   = 1.2;
params.P_CPU   = 0.004;

params.alpha = 9.61;
params.beta  = 0.16;
params.etaL  = 2.3;
params.etaN  = 34;

params.Vmax = 12;
params.dt   = 0.2;

params.N_gNB = 4;

%% ==========================================================
%                    TASK GENERATION
% ==========================================================
for i = 1:params.N_TASK
    Task(i).L        = randi([2000 6000]);
    Task(i).rho      = randi([80 200]);
    Task(i).deadline = rand*1.5 + 1.5;
    Task(i).done     = 0;
    Task(i).uav      = 0;
    Task(i).offloadType = 0;   % 0=local, 1=offload
    Task(i).targetgNB = 0;
end

%% ==========================================================
%                    UAV INITIALIZATION
% ==========================================================
for u = 1:params.N_UAV
    UAV(u).pos   = rand(1,2)*params.Area;
    UAV(u).vel   = rand(1,2)*params.Vmax;
    UAV(u).trust = 0.9;
    UAV(u).target= rand(1,2)*params.Area;
end

% gNB positions
gNB = [params.Area*0.25, params.Area*0.25;
       params.Area*0.25, params.Area*0.75;
       params.Area*0.75, params.Area*0.25;
       params.Area*0.75, params.Area*0.75];

% Colors
colorsUAV  = [1 1 0; 0 1 0; 0.6 0 0.6; 0.5 0.7 1; 1 0 0; 0 0.8 0.8]; % UAV distinct
colorsgNB = repmat([0.7 0.5 1],params.N_gNB,1);                        % gNB lilac
Offload_color = [0 0.8 0];                                              % green

%% ==========================================================
%                     DQN PARAMETERS
% ==========================================================
stateDim  = 7; 
actionDim = 2; 
hidden    = 32;

W1 = randn(hidden,stateDim)*0.1;
b1 = zeros(hidden,1);
W2 = randn(actionDim,hidden)*0.1;
b2 = zeros(actionDim,1);

gamma = 0.95;
lr    = 0.001;
eps   = 1.0;
epsMin= 0.05;
epsDec= 0.995;

%% ==========================================================
%                        LOGS
% ==========================================================
EnergyLog = [];
DelayLog  = [];
RewardLog = [];
MissLog   = [];
FinishTime = zeros(params.N_TASK,1);

UAV_paths = cell(params.N_UAV,1);
for u=1:params.N_UAV
    UAV_paths{u} = UAV(u).pos;
end

%% ==========================================================
%                    MAIN LOOP (MDP)
% ==========================================================
for k = 1:params.N_TASK
    u = randi(params.N_UAV);
    
    % UAV mobility update (Random Waypoint)
    dir = UAV(u).target - UAV(u).pos;
    if norm(dir) < 10
        UAV(u).target = rand(1,2)*params.Area;
        dir = UAV(u).target - UAV(u).pos;
    end
    dir = dir/norm(dir);
    UAV(u).vel = dir*params.Vmax;
    UAV(u).pos = UAV(u).pos + UAV(u).vel*params.dt;
    UAV_paths{u} = [UAV_paths{u}; UAV(u).pos];
    
    % Channel & rate
    d_gNB = vecnorm(UAV(u).pos - gNB,2,2);
    PL = pathlossU2G(d_gNB,params);
    rate_gNB = params.B*log2(1 + params.P_UAV*10.^(-PL/10)/(params.B*params.sigma2));
    
    % Nearest UAV
    other_UAVs = UAV; other_UAVs(u)=[];
    distUAVs=zeros(params.N_UAV-1,1);
    for idx=1:params.N_UAV-1
        distUAVs(idx)=norm(UAV(u).pos - other_UAVs(idx).pos);
    end
    nearestUAVDist = min(distUAVs);
    
    % Local computation
    D_local = Task(k).L*Task(k).rho/params.fc;
    
    % Offload to gNB
    [maxRate, idx_gNB] = max(rate_gNB);
    D_off = Task(k).L/maxRate + D_local;
    
    slack = Task(k).deadline - min(D_local,D_off);
    
    % State vector
    state = [min(d_gNB)/params.Area;
             norm(UAV(u).vel)/params.Vmax;
             maxRate/1e7;
             slack;
             UAV(u).trust;
             Task(k).deadline/3;
             nearestUAVDist/params.Area];
    
    % Action (ε-greedy)
    if rand<eps
        action = randi([0 1]);
    else
        Q = W2*relu(W1*state+b1)+b2;
        [~,action] = max(Q);
        action=action-1;
    end
    
    % Environment step
    if action==0
        D=D_local; E=params.P_CPU*Task(k).L*Task(k).rho;
    else
        D=D_off; E=params.P_UAV*Task(k).L/maxRate + params.P_CPU*Task(k).L*Task(k).rho;
        Task(k).targetgNB = idx_gNB;
    end
    
    success = D<=Task(k).deadline;
    miss = ~success;
    UAV(u).trust = 0.95*UAV(u).trust + 0.05*success;
    
    % Reward
    r = 0.5*UAV(u).trust -0.3*(D/Task(k).deadline) -0.2*(E/1000) -0.8*miss;
    
    % Q update
    Q = W2*relu(W1*state+b1)+b2;
    target=Q; target(action+1)=r; delta=target-Q;
    W2 = W2 + lr*(delta*(relu(W1*state+b1))');
    W1 = W1 + lr*((W2'*delta).*drelu(W1*state+b1))*state';
    
    % Logs
    EnergyLog(end+1)=E; DelayLog(end+1)=D;
    RewardLog(end+1)=r; MissLog(end+1)=miss;
    FinishTime(k)=sum(DelayLog);
    Task(k).done=success; Task(k).uav=u;
    
    %% Visualization (UAV + Offloading)
    figure(2); clf; hold on;
    axis([0 params.Area 0 params.Area]); axis square;
    
    % gNBs
    for g=1:params.N_gNB
        scatter(gNB(g,1),gNB(g,2),200,colorsgNB(g,:),'filled');
        text(gNB(g,1)+10,gNB(g,2),sprintf('gNB%d',g));
    end
    
    % UAVs
    for i=1:params.N_UAV
        plot(UAV_paths{i}(:,1),UAV_paths{i}(:,2),'-','Color',colorsUAV(i,:),'LineWidth',1.5);
        scatter(UAV(i).pos(1),UAV(i).pos(2),120,colorsUAV(i,:),'filled');
        text(UAV(i).pos(1)+10,UAV(i).pos(2),sprintf('UAV%d',i));
    end
    
    % Offloading arrow
    if action==1
        quiver(UAV(u).pos(1),UAV(u).pos(2),...
               gNB(idx_gNB,1)-UAV(u).pos(1), gNB(idx_gNB,2)-UAV(u).pos(2),0,...
               'Color',Offload_color,'LineWidth',1.5,'MaxHeadSize',2);
    end
    
    title(sprintf('Task %d / %d',k,params.N_TASK));
    drawnow;
    eps = max(eps*epsDec,epsMin);
end

%% ==========================================================
%                    TASK QUEUE (10 tasks)
% ==========================================================
figure('Name','Task Queue','Color','w'); hold on;
queueWidth=10; queueHeight=0.25; xStart=1; yStart=0.5;
axis([0 12 0 1]); axis off;
queueColors=lines(10); % 10 distinct colors
cellWidth=queueWidth/10;
for i=1:10
    rectangle('Position',[xStart+(i-1)*cellWidth,yStart,cellWidth,queueHeight],...
        'FaceColor',queueColors(i,:),'EdgeColor','k','LineWidth',0.6);
    text(xStart+(i-0.5)*cellWidth, yStart+queueHeight/2,...
        sprintf('Task%d',i),'HorizontalAlignment','center','VerticalAlignment','middle','FontWeight','bold','FontSize',9,'Color','k');
end
rectangle('Position',[xStart,yStart,queueWidth,queueHeight],'EdgeColor','k','LineWidth',1);
text(xStart+queueWidth/2, yStart+queueHeight+0.15,'Task Queue (10 tasks)','HorizontalAlignment','center','FontWeight','bold');

%% ==========================================================
%                    FINAL METRICS
% ==========================================================
fprintf('\n============= FINAL RESULTS =============\n');
fprintf('Total Tasks              : %d\n',params.N_TASK);
fprintf('Successful Tasks         : %d\n',sum([Task.done]));
fprintf('Deadline Miss Ratio      : %.3f\n',mean(MissLog));
fprintf('Average Delay (s)        : %.3f\n',mean(DelayLog));
fprintf('Average Energy (J)       : %.3f\n',mean(EnergyLog));
fprintf('Average Trust            : %.3f\n',mean([UAV.trust]));
fprintf('Average Reward           : %.3f\n',mean(RewardLog));
fprintf('Throughput (tasks/s)     : %.3f\n',params.N_TASK/max(FinishTime));
fprintf('Makespan (s)             : %.3f\n',max(FinishTime));
fprintf('========================================\n');

%% ==========================================================
%% ==========================================================
%                    SAVE RESULTS TO EXCEL
% ==========================================================
T_params = struct2table(params,'AsArray',true);
writetable(T_params,'SystemParameters.xlsx');
TaskTable = struct2table(Task);
writetable(TaskTable,'TaskResults.xlsx');

%% ==========================================================
%                    RELU FUNCTIONS
% ==========================================================
function y = relu(x)
    y = max(0,x);
end

function y = drelu(x)
    y = double(x>0);
end

function PL = pathlossU2G(d,p)
    theta = atan(p.H./d);
    P = 1./(1+p.alpha*exp(-p.beta*(theta-p.alpha)));
    PL = 20*log10(4*pi*p.fc*sqrt(d.^2+p.H^2)/p.c) + P*p.etaL + (1-P)*p.etaN;
end
